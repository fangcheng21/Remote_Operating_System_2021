function [ output_args ] = EventFunctionAtDoubleHit(  )
%EVENTFUNCTIONATDOUBLEHIT 
% The event to be performed at the double touch in the Z direction of the
% robot end effector

beep()


end

