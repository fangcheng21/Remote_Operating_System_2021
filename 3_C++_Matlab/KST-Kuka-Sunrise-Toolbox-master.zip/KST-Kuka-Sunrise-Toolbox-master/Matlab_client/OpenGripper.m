function OpenGripper(t_Kuka)
%% Copyright: Mohammad SAFEEA 11th-April-2018
setPin1Off(t_Kuka);
pause(1);
setPin11On(t_Kuka);
pause(1);
end