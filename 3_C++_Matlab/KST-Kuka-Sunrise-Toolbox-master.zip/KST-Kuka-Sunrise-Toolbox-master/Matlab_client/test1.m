%%%%%%%%%%%%%%%%%
t_server=tcpip('127.0.0.1',6668,'NetworkRole','server');%与第一个请求连接的客户机建立连接，端口号为6668，类型为服务器。
t_server.InputBuffersize=11000;%缓冲区放大到10000
fopen(t_server);%打开服务器，直到建立一个TCP连接才返回；
sprintf("成功建立连接");
pause(1);

while(1)
    
    while(1)%等到缓存区有数据就跳出循环
     if  t_server.BytesAvailable>0
         %t_server.BytesAvailable%显示缓存区字节数
        break;
     end
    end
data_recv=(fread(t_server,t_server.BytesAvailable));%从缓冲区读取数字数据


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [data1]= transform(data)
%recv1 = dec2hex(data);%ACSII码转换成16进制

%recv2 = [];                      %将数据按小端形式放在一起
%for i = 1:length(recv1)
%    recv2 = [recv2,recv1(i,:)]; %小端模式
%end

%count = 0;
%recv3 = []; %转化成double
%while count < (length(recv1))/8
%    recv3 = [recv3,hex2num(recv2((count*16+1):(count*16+16)))];
%    count = count + 1;
%end

%for j=1:length(recv3)
%recv4{j}=recv3(j);
%end
%data1 = recv4;

%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
recv4 = transform(data_recv);
send3 = [];
if recv4{1}==1
        disp('1');
        send3 = transform1(jPos);
        fwrite(t_server,send3,'char');
elseif recv4{1}==2
        disp("2");
        send3 = transform1(pos);
        fwrite(t_server,send3,'char');
elseif recv4{1}==3
        disp("3");
        send3 = transform1(m);
        fwrite(t_server,send3,'char');
elseif recv4{1}==4
        disp("4");
        send3 = transform1(f);
        fwrite(t_server,send3,'char');
elseif recv4{1}==5
        disp("5");
        send3 = transform1(cpos);
        fwrite(t_server,send3,'char');
elseif recv4{1}==10
     disp("10"); 
    fclose(t_server);
    disp("关闭连接");
    break;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%send0=cell2mat(f);
%send1=num2hex(send0);%转成16进制

%send2=[];
%for j = 1:length(send0)
%    send2 = [send2,send1(j,:)]; %小端模式 %小端模式
%end

%count1 = 0;
%send3 = []; 

%转化成double
%while count1 < length(send0)*8
%    send3 = [send3,hex2dec(send2((count1*2+1):(count1*2+2)))];
%    count1 = count1 + 1;
%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%fwrite(t_server,send3,'char');

end



%fclose(t_server);
