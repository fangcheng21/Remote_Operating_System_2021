function fcn_errorMessage(message)
%% About:
% Show an error message in a popup dialog box

% Copyright: Mohammad SAFEEA, 10th-July-2018

    title='Error message';
    errordlg(message,title);
end